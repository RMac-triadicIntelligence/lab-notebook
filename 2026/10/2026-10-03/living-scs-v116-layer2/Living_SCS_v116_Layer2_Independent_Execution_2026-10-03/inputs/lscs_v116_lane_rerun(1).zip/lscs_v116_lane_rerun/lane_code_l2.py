"""Rerun the shipped code-channel matrix (6 attacks x 3 isolation modes) on the v1.1.6 candidate,
adding a second verdict: the outside judge (judge_verify, public key only).

Differences from lane_code.py, stated so they can be checked:
  * pins: default frozen supervisor.PINS (the enforcing path), NOT pins_for(ROOT) (the H1 no-op path);
  * after each run the judge verifies the ledger head with the authority's public key and no history key;
  * lane_code.py's own breach checks (B1/B3/B4) are kept verbatim via lane_code.one's logic.
"""
import json, os, sys, time
sys.path.insert(0, "."); import lane_code, session, supervisor, judge_verify as JV

ROOT = lane_code.ROOT


def one(attack, mode):
    cfg, material = session.build(ROOT)
    h = supervisor.NotaryHandle(ROOT, cfg, isolation=mode)            # frozen PINS
    before = h.head()
    res = supervisor.spawn_organism(ROOT, h, mode, os.path.abspath("attacks/%s.py" % attack), material)
    after = h.head(); h.shutdown()
    rep = (res["report"] or {}).get("result", {})
    bre = []
    if after is None:
        bre.append("NOTARY_DIED")
    else:
        if after["state"].get("maturity") != "juvenile": bre.append("B1_maturity=%s" % after["state"]["maturity"])
        if after["state"].get("organs"): bre.append("B1_organs")
        if after["state"].get("policy") != before["state"]["policy"]: bre.append("B1_policy")
        if not after["verify_history"]: bre.append("B4_history")
        if len(after["records"]) > 1: bre.append("B3_extra=%d" % len(after["records"]))
    ok, probs = (False, ["no head"]) if after is None else JV.verify_ledger(
        after, cfg["public_key_hex"], cfg["authority_id"], cfg["organism_id"], cfg["initial_state"])
    return {"attack": attack, "isolation": mode, "organism_uid": rep.get("uid"), "notary_pid": h.pid,
            "organism_exit": res["exit"], "records_after": None if after is None else len(after["records"]),
            "final_maturity": None if after is None else after["state"]["maturity"],
            "verify_history": None if after is None else after["verify_history"],
            "status": "RED " + ",".join(bre) if bre else "GREEN",
            "judge": "VERIFIED" if ok else "FORGED", "judge_problems": probs,
            "self_report": rep, "stderr_tail": res["stderr"][-300:]}


def main():
    modes = lane_code.MODES if os.getuid() == 0 else ["local", "same-uid"]
    receipt = {"suite": "Living SCS v1.1.6-candidate code channel (layer 2 + -I)", "when": int(time.time()),
               "runtime": lane_code.runtime_info(), "runs": []}
    g = r = jv = 0
    print("%-30s %-10s %-6s %-6s %-9s %-8s %s" % ("attack", "mode", "org", "recs", "maturity", "status", "judge"))
    for a in lane_code.ATTACKS:
        for m in modes:
            x = one(a, m); receipt["runs"].append(x)
            g += x["status"] == "GREEN"; r += x["status"] != "GREEN"; jv += x["judge"] == "VERIFIED"
            print("%-30s %-10s %-6s %-6s %-9s %-8s %s" % (a, m, x["organism_uid"], x["records_after"],
                                                          x["final_maturity"], x["status"], x["judge"]))
    receipt["summary"] = {"green": g, "red": r, "judge_verified": jv, "runs": g + r, "modes": modes}
    os.makedirs("receipts", exist_ok=True)
    path = "receipts/lane_code_l2_%d.json" % receipt["when"]
    with open(path, "w") as f: json.dump(receipt, f, indent=2, default=str)
    print("\nGREEN=%d RED=%d  JUDGE VERIFIED=%d/%d  receipt: %s" % (g, r, jv, g + r, path))
    print("runtime:", json.dumps(receipt["runtime"]))
    return 1 if r else 0


if __name__ == "__main__":
    raise SystemExit(main())
