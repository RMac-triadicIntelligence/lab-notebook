"""Prove the lane can FAIL, now with the outside judge as a second, independent verdict.
Mutants are the shipped NM1/NM2 (from run_notary_mutants.py, unchanged) run in all three modes.
pins=pins_for(tree) is required here by design: the mutant IS the changed notary under test."""
import os, shutil, sys
sys.path.insert(0, "."); import run_notary_mutants as RM, session, supervisor, judge_verify as JV
ROOT = RM.ROOT

def run(tree, mode):
    cfg, material = session.build(ROOT)
    h = supervisor.NotaryHandle(tree, cfg, isolation=mode, pins=supervisor.pins_for(tree))
    supervisor.spawn_organism(tree, h, mode, os.path.abspath("attacks/code_04_protocol_abuse.py"), material)
    after = h.head(); h.shutdown()
    lane = "RED B1_maturity=%s" % after["state"]["maturity"] if after["state"]["maturity"] != "juvenile" else "GREEN"
    ok, probs = JV.verify_ledger(after, cfg["public_key_hex"], cfg["authority_id"], cfg["organism_id"], cfg["initial_state"])
    return lane, ("VERIFIED" if ok else "FORGED"), probs, after["verify_history"]

variants = {"shipped (v1.1.6-candidate)": open("notary.py").read(), **RM.mutants()}
for name, src in variants.items():
    assert name.startswith("shipped") or src != variants["shipped (v1.1.6-candidate)"], name + ": mutation did not apply"
    for mode in ("local", "same-uid", "split-uid"):
        t = RM.build_tree(src)
        for d, _, fs in os.walk(t): os.chmod(d, 0o755)
        lane, judge, probs, vh = run(t, mode); shutil.rmtree(t, ignore_errors=True)
        print("%-27s %-9s lane=%-20s notary verify_history=%-5s judge=%s %s" % (name, mode, lane, vh, judge, probs[-1:] if probs else ""))
