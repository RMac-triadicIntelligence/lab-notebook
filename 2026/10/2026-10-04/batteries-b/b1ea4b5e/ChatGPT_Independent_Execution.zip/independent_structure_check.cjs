'use strict';
const fs=require('fs');
const {Commons}=require('./run/commons_kernel_v0_3_1.cjs');
const {Authorizer}=require('./run/authority.cjs');
const auth=new Authorizer('independent-structure-key');
const modes={FULL_P:{},CLAIM_P:{groundMode:'claim'},FADE_P:{groundMode:'parable'},DEEPEN_P:{groundMode:'parable',stage:'deepen'},RESONATE_P:{groundMode:'parable',stage:'resonate'}};
const plants={perLineage:4,falseCount:2,dwell:4};
let checked=0,mismatch=0;const first=[];
for(let seed=1;seed<=200;seed++){if(seed===7)continue;let baseline;
 for(const [name,o] of Object.entries(modes)){
 const c=new Commons(seed,auth.publicKey,{...o,plant:plants});
 const labels=JSON.stringify(['A','B'].map(l=>[l,[...c._planted[l]],c.world.map(w=>w.truth)]));
 if(baseline===undefined)baseline=labels;else{checked++;if(labels!==baseline)mismatch++;}
 if(seed===1)first.push({mode:name,plantLabels:['A','B'].map(l=>[l,[...c._planted[l]]]),parables:c.parables});
 }
}
const shapes={};for(const stage of ['fade','deepen','resonate']){const c=new Commons(1,auth.publicKey,{groundMode:'parable',stage});shapes[stage]=[0,2,4,8,12].map(k=>({readerSamples:k,tellerDwell:4,weight:c._stage(k,4)}));}
const result={matchedPlantComparisons:checked,mismatches:mismatch,shapes,seed1Prehistories:first};
fs.writeFileSync(__dirname+'/independent_structure_check.json',JSON.stringify(result,null,2));
console.log(JSON.stringify({matchedPlantComparisons:checked,mismatches:mismatch,shapes}));
