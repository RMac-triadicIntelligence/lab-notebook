import csv,json,math,statistics,hashlib
from collections import defaultdict
from pathlib import Path
root=Path(__file__).resolve().parent
s=json.loads((root/'run/evidence/summary.json').read_text())
rows=list(csv.DictReader((root/'run/evidence/paired-runs.csv').open()))
tot=defaultdict(lambda:defaultdict(lambda:defaultdict(float)))
for r in rows:
 for k,v in r.items():
  if k not in ('condition','seed','generation') and v:tot[r['condition']][int(r['seed'])][k]+=float(v)
def pair(a,b,f):
 d=[tot[a][i][f]-tot[b][i][f] for i in sorted(tot[a])];mu=statistics.mean(d);se=statistics.stdev(d)/math.sqrt(len(d));return {'mean':mu,'ci95':[mu-1.96*se,mu+1.96*se]}
def pooled(mode,key):return sum(x[key] for x in tot[mode].values())
def rate(mode,cl,num,den):
 n=pooled(mode,cl+'_'+num);d=pooled(mode,cl+'_'+den);return n/d if d else None
shapes={a:pair(a,'FADE','restoredTrue') for a in ('DEEPEN','RESONATE')}
checks={}
for a,label in [('DEEPEN','B1_deepenBeatsFade'),('RESONATE','B2_resonateBeatsFade')]:
 got=shapes[a];reported=s['statistics'][label];checks[a+'_paired_recomputed']=round(got['mean'],4)==reported['mean'] and [round(x,4) for x in got['ci95']]==reported['ci95']
plants={}
for a in ('FULL_P','CLAIM_P','FADE_P','DEEPEN_P','RESONATE_P'):
 plants[a]={cl:{'wrongSettledRate':rate(a,cl,'wrongSettled','sampledWrong'),'falseCorrectionRate':rate(a,cl,'falseCorrections','sampledRight')} for cl in ('PF','PT')}
checks['paired_row_count']=len(rows)==199*12*12
checks['sources_match']=all(hashlib.sha256((root/'run'/f).read_bytes()).hexdigest()==v for f,v in s['sources'].items())
checks['frozen_manifest_matches']=all(hashlib.sha256((root/'run'/line.split('  ')[1]).read_bytes()).hexdigest()==line.split('  ')[0] for line in (root/'run/FROZEN_BEFORE_RUN.sha256').read_text().splitlines())
long=s['statistics']['longHorizonDescriptive'];bound=math.exp(-3)
checks['B4_long_horizon_rates_omitted_from_runner_verdict']=all(long[m]['wrongSettledRate']<=bound and long[m]['falseCorrectionRate']<=bound for m in ('FADE','DEEPEN','RESONATE'))
reg=root/'regression/evidence';old=root.parent/'commons_v03_review/run/evidence'
checks['regression_paired_byte_identical']=(reg/'paired-runs.csv').read_bytes()==(old/'paired-runs.csv').read_bytes()
checks['regression_long_byte_identical']=(reg/'long-horizon.csv').read_bytes()==(old/'long-horizon.csv').read_bytes()
checks['regression_receipt_reproduced']=(reg/'receipt.txt').read_text().splitlines()[0]=='receipt 3450e400b353e38a7427fc1a53f1401ab49fb7a18914f1167e14189829cfbbfa'
result={'checks':checks,'pairedRecomputed':shapes,'plantedRatesRecomputed':plants,'generationEpisodes':s['generationEpisodes'],'receipt':(root/'run/evidence/receipt.txt').read_text().splitlines()[0], 'regression_receipt':(reg/'receipt.txt').read_text().splitlines()[0]}
(root/'independent_recalculation.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
