# Constitutional Commons v0.3.1 — Perspective Shapes and Matched Prehistory
Soulshine · 4 October 2026 · successor to v0.3 (receipt 3450e400…bfa)

## The question
Rusty McMurray: *"We made the story fade as you walk past the teller. Real parables do the opposite: they mean more the closer your life comes to theirs."*

## Witness and integrity
- **Preregistration:** SHA-256 `5786c4575685c996a06838ed10384de12bcf1076c8a03722a05178f446b71d26`, posted publicly by Rusty before the run as the external witness of when it was frozen. Sources were verified unchanged against `FROZEN_BEFORE_RUN.sha256` immediately before the run.
- **Regression before freezing:** the v0.3 battery run against the v0.3.1 kernel reproduced v0.3 receipt `3450e400…bfa` and both CSVs byte-for-byte.
- **Execution:** 199 seeds × 12 conditions × 12 generations, plus 30 seeds × 200 generations × 4 modes. 52,656 generation episodes, ~250 s.
- **Receipt** `1025cb60e445f45fc3bee51d2456ac1da1af26d3ba2127b3cd6084ac45b75ffb`, reproduced on a second clean run with byte-identical CSVs.
- **Process correction before freezing:** the preregistration was first dated October 3, the wrong day. It was corrected to October 4 and re-hashed before anything was posted.

## Perspective shapes tested
k = the reader's own evidence samples at the gate; D = the teller's dwell.
- **fade** (v0.3): 1 while k ≤ D, then exp(−(k−D)/(1+D)). The story falls silent once you pass the teller.
- **deepen**: (1+k)/(1+D) while k < D, then 1. The story means more as your walk approaches theirs, and keeps it.
- **resonate**: (1+min(k,D))/(1+max(k,D)). The story means most when your walk is as long as theirs.

## Results, mean per seed over 12 generations
| Condition | True restorations | Encounters | Wrong lock-in | False corrections |
|---|---|---|---|---|
| FROZEN (= v0.2, bit-identical) | 141.7 | 2874 | 4.08 | 2.37 |
| FADE (v0.3) | 131.2 | 2820 | 3.71 | 2.21 |
| DEEPEN | 123.0 | 2636 | 3.68 | 1.93 |
| RESONATE | 116.0 | 2597 | 3.48 | 1.84 |
| NO_GROUND | 74.8 | 2115 | 2.21 | 1.11 |

Long horizon, restorations per generation over generations 101–200: FULL 14.09, FADE 13.54, DEEPEN 11.25, RESONATE 10.97. The deepening gap *widens* as stories accumulate.

## Preregistered verdicts
| | Prediction | Result |
|---|---|---|
| B1 | Deepen beats fade | **FAILED.** −8.2 restorations (CI −9.5 to −6.9) and −184 encounters. |
| B2 | Resonate beats fade | **FAILED.** −15.2 (CI −16.5 to −14.0) and −223 encounters. |
| B3 | Lens persists under deepening | HELD. Cross-lineage −27.7 (CI −29.0 to −26.4). |
| B4 | Truth intact | HELD. FROZEN = FULL in 199/199 seeds. Story-decided = 0 in every parable condition. All rates ≤ 0.0498. 5,271,495 shared evidence keys, 0 mismatches. |
| A1 | The answer pocket is causal | HELD. With identical planted first records, CLAIM_P locks in the wrong belief at 12.0% at planted-false gates versus 0.32% at planted-true gates. DiD versus FULL_P is +0.115 (CI 0.110 to 0.121) on lock-in and +0.104 (CI 0.095 to 0.114) on false correction. |
| A2 | Parables carry no pocket, within ±2 points | HELD for all three shapes. The DiD CIs lie within [−0.003, +0.008] on both measures, so there is no excess beyond 2 percentage points (about 0.8 at most). |
| A3 | Probes refuse for the right reason | HELD. 45/45, with the strict self-sign check (`ERR_CRYPTO_INVALID_KEY_OBJECT_TYPE`, held key `public`). Inverting the truth and plant labels left behavior unchanged. |

## What this establishes
1. **In this model, a story is most useful at the threshold.** Approach cost is the binding constraint. A story that means little until you have walked far does nothing at the door, where the hard step is. Fade puts full meaning at the threshold and withdraws later; deepening and resonance hold it back at the threshold. That is the whole failure: 184–223 fewer encounters.
2. **The operationalization conflated two things.** Rusty's intuition is that meaning *grows* with lived closeness. The shapes tested also made meaning *small at the start*, and the start is what this model rewards. The data reject "small at the start," and they do not test "grows later" in isolation.
3. **Deepening is more careful.** It produced fewer false corrections (−0.28 and −0.37 versus fade) and lower long-horizon error rates (lock-in 1.37% and 1.32% versus 1.60%). It is slower, but it errs less per gate. That is a real tradeoff, not just a loss.
4. **The answer pocket is now causal, not correlational.** With identical planted histories, reading answers produces a 12% lock-in pocket wherever the first story was false. Parables, in every shape, show no excess beyond 2 points.
5. **Whether answers look good on average depends on how often first stories are true.** In v0.3, about 95% of first stories were true and CLAIM locked in fewer wrong beliefs village-wide. With half the planted stories false, CLAIM_P locks in about twice as many as FULL_P (8.57 versus 4.38) while still restoring faster (200.7 versus 153.3). v0.3's Q2 failure was a base-rate effect.

## What it does not establish
- Magnitudes and shapes are authored, and meaning acts only on approach cost. In this kernel there is no channel through which "meaning more when your life is close" could act at the moment of crisis.
- The planted design gives every condition the same 4 first records per lineage. In parable mode, planted false and true stories are byte-identical by design, so A2 tests for hidden channels, not for robustness to a content difference.
- The world is closed at 16 gates; it is same-process JavaScript with a deterministic test key.

## Next hypothesis, not yet preregistered
Separate the two things the shapes conflated. Keep full meaning at the threshold (fade's strength), and let the deepening part act where Rusty's intuition places it: **at reception**, the moment a person has to accept forgiveness after the evidence has already turned them. Reception happens after the conclusion, so it has no path to truth. The test: does a story that resonates with where you are help you *receive*, without making you approach less?

## Reproduce
- `node run-commons-v0_3_1-battery.cjs`: expect B1 and B2 false, the rest true, receipt `1025cb60…5ffb`.
- `node run-commons-v0_3_1-battery.cjs --smoke` prints `ok`.
